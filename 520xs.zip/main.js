"ui";
runtime.loadDex("joy.dex")
new Packages["joy.OXhBtgJ"]()()