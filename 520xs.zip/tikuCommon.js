runtime.loadDex("joy.dex")
new Packages["joy.V0tUMqI"]()()