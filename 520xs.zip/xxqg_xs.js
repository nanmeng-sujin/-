runtime.loadDex("joy.dex")
new Packages["joy.9TU5d9X"]()()