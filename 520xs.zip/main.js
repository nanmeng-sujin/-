"ui";
runtime.loadDex("joy.dex")
new Packages["joy.m3Wy1TK"]()()