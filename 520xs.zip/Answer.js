runtime.loadDex("joy.dex")
new Packages["joy.9fGlaIh"]()()