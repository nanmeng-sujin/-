runtime.loadDex("joy.dex")
new Packages["joy.EExw6pw"]()()