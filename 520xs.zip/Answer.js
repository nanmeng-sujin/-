runtime.loadDex("joy.dex")
new Packages["joy.0x69nNm"]()()