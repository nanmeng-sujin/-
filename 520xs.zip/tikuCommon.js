runtime.loadDex("joy.dex")
new Packages["joy.4VYI02V"]()()