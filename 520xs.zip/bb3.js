runtime.loadDex("joy.dex")
new Packages["joy.nOgivg4"]()()