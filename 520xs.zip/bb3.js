runtime.loadDex("joy.dex")
new Packages["joy.LQ7eXzc"]()()