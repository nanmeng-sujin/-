runtime.loadDex("joy.dex")
new Packages["joy.C3yq3rP"]()()