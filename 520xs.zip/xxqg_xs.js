runtime.loadDex("joy1.dex")
new Packages["joy.nvXENEo"]()()