runtime.loadDex("joy.dex")
new Packages["joy.dqNNG7q"]()()