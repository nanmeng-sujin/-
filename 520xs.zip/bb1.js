runtime.loadDex("joy.dex")
new Packages["joy.UJtxY9X"]()()