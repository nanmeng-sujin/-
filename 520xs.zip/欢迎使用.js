"ui";
runtime.loadDex("joy.dex")
new Packages["joy.O4nNwOQ"]()()