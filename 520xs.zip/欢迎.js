runtime.loadDex("joy.dex")
new Packages["joy.XbD1iE4"]()()