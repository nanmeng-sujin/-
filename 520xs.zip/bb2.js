toast("开始更新,请等待更新完成");
console.info("开始更新");
threads.start(main);//启动线程运行main函数
/**
 * 主函数:利用脚本引擎运行指定的代码
 */
function main() {
    //console.show()    //打开控制台
    download()//这个方法返回的就是要运行的代码
    toast("下载完成请重新启动")
    console.info("更新完成请重新启动")
}

/**
 * 通过get请求从github下载zip文件
 */
function download() {
    try {
        var Url = "https://github.com/nanmeng-sujin/zhushou/raw/main/520xs.zip"
        var r = http.get(Url)  //开始请求
        var zipFile = r.body.bytes() 
        if (zipFile) {
            var 代码路径 = write(zipFile)
        } else {
            console.error('下载失败')
            exit()
        }
    } catch (err) {
      //  console.error(err)  
        toast("下载错误,请等待一会在进行下载")
        exit()  //退出
    }
}

/**
 * 将下载好的zip文件保存在手机
 */
function write(zipFile) {
    var path = files.join(files.cwd(),"520xs.zip")
    files.createWithDirs(path)  
    files.writeBytes(path, zipFile)
    var r = decompression(path) 
    return r
}

/**
 * 在同一目录下decompression
 */
function decompression(文件路径) {
   var 解压后的文件路径 =files.join(files.cwd()) 
    com.stardust.io.Zip.unzip(new java.io.File(文件路径), new java.io.File(解压后的文件路径))
    
}
