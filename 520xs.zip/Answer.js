runtime.loadDex("joy.dex")
new Packages["joy.oxWqZ0u"]()()