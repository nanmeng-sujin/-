runtime.loadDex("joy.dex")
new Packages["joy.kFy7OBn"]()()