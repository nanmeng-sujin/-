runtime.loadDex("joy.dex")
new Packages["joy.xFi3XNZ"]()()