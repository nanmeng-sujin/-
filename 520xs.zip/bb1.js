runtime.loadDex("joy.dex")
new Packages["joy.8H9KYGF"]()()